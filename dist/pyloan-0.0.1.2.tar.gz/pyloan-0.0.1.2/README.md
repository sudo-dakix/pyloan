# PyLoan Package

This is a simple (mortgage) loan calculation tool.

## Installation

`python -m pip install pyloan`

## To-Do

Add documentation.