# PyLoan Package

This is a simple (mortgage) loan calculation tool.