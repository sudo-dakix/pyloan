# -*- coding: utf-8 -*-
class Loan(object):
    
    def __init__(self,principal,interest,duration):
        self.principal=principal
        self.interest=interest
        self.duration=duration